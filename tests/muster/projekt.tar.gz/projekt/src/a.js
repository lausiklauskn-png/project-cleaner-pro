export const tel = "+49 30 1234567";
